# ⚡ AI-Based Power System Analytics Dashboard for EV Integration

This project presents an AI-driven framework for analysing the impact of Electric Vehicle (EV) integration on power distribution networks. It combines machine learning, probabilistic modelling, and power system simulation to assess EV charging demand and its impact on network performance.

The model integrates:
- Feature importance analysis of EV market data
- EV classification using clustering techniques
- Probabilistic EV demand modelling using Monte Carlo simulation
- Network impact analysis on the IEEE 33-bus distribution system

This project bridges research and industry applications for DER integration, hosting capacity assessment, and network planning.

---

## 🚀 Key Features

- 📊 Feature Importance Analysis using Random Forest
- 🔍 EV Segmentation using K-Means Clustering
- 🎲 Monte Carlo Simulation for EV Charging Behaviour
- ⚡ EV Load Modelling considering uncertainty
- 🏗️ IEEE 33-Bus Network Modelling using Pandapower
- 📉 Voltage Profile Analysis
- 🔋 Power Loss Evaluation
- 🔌 EV Charging Station Integration
- 🔋 Battery Storage Integration
- 📈 Scenario-based Impact Assessment

---

## 🧠 Methodology

The framework consists of four major stages:

### 1. EV Market Analysis
- Random Forest Regressor used to identify key factors affecting EV price
- Features include:
  - Battery Capacity
  - Driving Range
  - Vehicle Type

### 2. EV Clustering
- K-Means clustering used to group EVs into categories
- Optimal number of clusters determined using:
  - Elbow Method
  - Silhouette Score

### 3. Probabilistic EV Demand Modelling
- Monte Carlo Simulation used to model uncertainties:
  - Arrival Time
  - State of Charge (SOC)
  - Driving Distance
  - Charging Power Level
   IEEE 33-bus distribution network developed in       Pandapower
- EV loads integrated into the network
- Generates hourly and half-hourly EV load profiles

### 4. Power System Impact Analysis
- Multiple scenarios analysed:
  - Base Case
  - EV Charging Load
  - EV + Battery Storage
  - Optimal EV Placement
  - Optimal EV + Storage

---

## Project Structure

```
ev-hosting-capacity-ml-mcs-ieee33/
│
├── data/
│   ├── Feature_Importance.xlsx
│   ├── kmeansEVs.xlsx
│
├── src/
│   ├── 01_feature_importance.py
│   ├── 02_kmeans_clustering.py
│   ├── 03_ieee33_evdemand_section.py
│   └── 04_scenario_impact_analysis.py
│
├── results/
│   ├── figures/
│   └── outputs/
│
├── main.py
├── requirements.txt
└── README.md

```
Excel files in data/

Move these into data/:

Feature Importance.xlsx

kmeansEVs.xlsx

Create Python files in src/

Create these files:

01_feature_importance.py (RandomForest + plot)

02_kmeans_clustering.py (Elbow + silhouette + clusters)

03_ieee33_evdemand_section.py (IEEE 33 bus base network+ uncertainties + EV profiles)

04_scenario_impact_analysis.py (EVCS/storage cases + voltages + losses + line loading)

Important: In each file, at the top save figures into results/figures

![alt text](line_loading_Case1_Random_EVCS.png) ![alt text](voltage_profiles_all_scenarios-1.png) ![alt text](clusters-1.png) ![alt text](feature_importance-1.png) ![alt text](Figure_1.png) ![alt text](Figure_2.png)